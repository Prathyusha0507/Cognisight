import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

function EditProduct() {
  const [product, setProduct] = useState({ name: '', price: '', description: '' });
  const [imageFile, setImageFile] = useState(null);
  const { id } = useParams();  
  const navigate = useNavigate();

  useEffect(() => {
    
    const fetchProduct = async () => {
      const res = await axios.get(`http://localhost:5000/product/${id}`);
      setProduct(res.data);
    };
    fetchProduct();
  }, [id]);

  const updateProduct = async () => {
    const formData = new FormData();
    formData.append('name', product.name);
    formData.append('price', product.price);
    formData.append('description', product.description);
    if (imageFile) formData.append('image', imageFile);

    try {
      await axios.put(`http://localhost:5000/edit/${id}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      alert('Product updated');
      navigate('/manage-products');
    } catch (err) {
      alert('Error updating product');
    }
  };
  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };


  return (
    <div>
      <div className='c1'>
      <nav >
        <Link to="/AddProducts" className='c5'>Add products</Link>
        <Link to="/manageproducts" className='c5'>Manage products</Link>
        <Link to="/" className='c5' onClick={handleLogout}>Logout</Link>
      </nav>
      </div>
      <h2>Edit Product</h2>
      <input
        placeholder="Product Name"
        value={product.name}
        onChange={(e) => setProduct({ ...product, name: e.target.value })}
      />
      <input
        placeholder="Price"
        value={product.price}
        onChange={(e) => setProduct({ ...product, price: e.target.value })}
      />
      <textarea
        placeholder="Product Description"
        value={product.description}
        onChange={(e) => setProduct({ ...product, description: e.target.value })}
      />
      <input type="file" accept="image/*" onChange={(e) => setImageFile(e.target.files[0])} />
      <button onClick={updateProduct}>Update</button>
    </div>
  );
}

export default EditProduct;
