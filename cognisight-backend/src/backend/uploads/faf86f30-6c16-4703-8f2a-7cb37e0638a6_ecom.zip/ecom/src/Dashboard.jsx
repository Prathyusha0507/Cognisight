import {Link} from 'react-router-dom';

function Dashboard() {
  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <body>
      <div className='c1'>
      <nav >
        <Link to="/AddProducts" className='c5'>Add products</Link>
        <Link to="/manageproducts" className='c5'>Manage products</Link>
        <Link to="/" className='c5' onClick={handleLogout}>Logout</Link>
      </nav>
      </div>
    <div>
      <h2>Welcome to Admin Dashboard</h2>
      
        
    </div>
    </body>
  );
}

export default Dashboard;
