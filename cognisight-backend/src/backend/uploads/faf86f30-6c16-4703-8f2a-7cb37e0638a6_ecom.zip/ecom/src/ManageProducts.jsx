import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';


function ManageProducts() {
  const [products, setProducts] = useState([]);

  const fetchProducts = async () => {
    const res = await axios.get('http://localhost:5000/products');
    setProducts(res.data);
  };

  const deleteProduct = async (id) => {
    await axios.delete(`http://localhost:5000/product/${id}`);
    fetchProducts();
  };
  const editProduct = (id) => {
    navigate(`/edit/${id}`); 
  };
  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };


  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <body className='b3'>
        <div className='c1'>
      <nav >
        <Link to="/AddProducts" className='c5'>Add products</Link>
        <Link to="/manageproducts" className='c5'>Manage products</Link>
        <Link to="/" className='c5' onClick={handleLogout}>Logout</Link>
      </nav>
      </div>
        <h2>Manage Products</h2>
    <div className='d3'>
      
      {products.map((p) => (
        <div key={p.id} style={{ marginBottom: 10 }}>
          <img src={`http://localhost:5000/uploads/${p.image}`} alt={p.name} style={{ width: 100 }} />
          <div>{p.name} - ${p.price}<br/>
            {p.description}
          </div>
          <br/>
          <button onClick={() => deleteProduct(p.id)}className='b4'>Delete</button>
          <button onClick={() => editProduct(p.id)} className='b4'>Edit</button>
        </div>
      ))}
    </div>
    <Link to='/AddProducts'className='bm'><button className='b4'> Add More products</button></Link>
    </body>
  );
}

export default ManageProducts;
